-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gostitelj: 127.0.0.1
-- Čas nastanka: 30. sep 2022 ob 00.47
-- Različica strežnika: 10.4.24-MariaDB
-- Različica PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Zbirka podatkov: `eucilnica`
--

-- --------------------------------------------------------

--
-- Nadomestna struktura pogleda `naloga_predmet`
-- (Oglejte si spodaj za resnični pogled)
--
CREATE TABLE `naloga_predmet` (
`id` int(11)
,`ime` varchar(30)
,`navodila` varchar(50)
,`datumObjave` timestamp
,`datumPoteka` datetime
,`idPredmeta` int(11)
,`token` varchar(300)
);

-- --------------------------------------------------------

--
-- Struktura tabele `naloge`
--

CREATE TABLE `naloge` (
  `id` int(11) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `navodila` varchar(50) NOT NULL,
  `datumObjave` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `datumPoteka` datetime NOT NULL,
  `idPredmeta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `naloge`
--

INSERT INTO `naloge` (`id`, `ime`, `navodila`, `datumObjave`, `datumPoteka`, `idPredmeta`) VALUES
(1, 'Prva naloga predmet 1', '', '2022-09-27 17:13:01', '2022-09-27 19:12:32', 1),
(2, 'Druga naloga predmet 1', '', '2022-09-27 17:13:01', '2022-09-27 19:12:32', 1);

-- --------------------------------------------------------

--
-- Struktura tabele `oddanenaloge`
--

CREATE TABLE `oddanenaloge` (
  `id` int(11) NOT NULL,
  `idNaloge` int(11) NOT NULL,
  `idUcenca` int(11) NOT NULL,
  `pot` varchar(130) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `oddanenaloge`
--

INSERT INTO `oddanenaloge` (`id`, `idNaloge`, `idUcenca`, `pot`) VALUES
(3, 1, 5, '5/1-Pika-Poka-bitnami.css');

-- --------------------------------------------------------

--
-- Struktura tabele `predmeti`
--

CREATE TABLE `predmeti` (
  `idPredmeta` int(11) NOT NULL,
  `imePredmeta` varchar(30) NOT NULL,
  `letnik` int(1) NOT NULL,
  `okrajsava` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `predmeti`
--

INSERT INTO `predmeti` (`idPredmeta`, `imePredmeta`, `letnik`, `okrajsava`) VALUES
(1, 'Matematika', 1, 'MAT'),
(2, 'Slovenscina', 1, 'SLO'),
(3, 'Anglescina', 1, 'ANG'),
(4, 'Racunalnistvo', 1, 'RAC'),
(7, 'Matematika', 2, 'MAT'),
(8, 'Racunalnistvo', 2, 'RAC'),
(9, 'Anglescina', 2, 'ANG');

-- --------------------------------------------------------

--
-- Struktura tabele `ucenci`
--

CREATE TABLE `ucenci` (
  `id` int(11) NOT NULL,
  `ime` varchar(20) NOT NULL,
  `priimek` varchar(20) NOT NULL,
  `datumPridruzitve` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `datumPrijave` datetime NOT NULL,
  `geslo` varchar(150) NOT NULL,
  `token` varchar(300) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktura tabele `ucenecpredmet`
--

CREATE TABLE `ucenecpredmet` (
  `idUcenecPredmet` int(11) NOT NULL,
  `idUcenec` int(11) NOT NULL,
  `idPredmet` int(11) NOT NULL,
  `datumPridruzitve` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `ucenecpredmet`
--

INSERT INTO `ucenecpredmet` (`idUcenecPredmet`, `idUcenec`, `idPredmet`, `datumPridruzitve`) VALUES
(2, 1, 2, '2022-09-29 17:41:24'),
(3, 1, 3, '2022-09-29 17:41:27'),
(4, 1, 4, '2022-09-29 17:41:32'),
(9, 1, 8, '2022-09-29 20:20:57'),
(10, 1, 7, '2022-09-29 20:22:10'),
(12, 1, 1, '2022-09-29 22:00:01'),
(14, 5, 1, '2022-09-29 22:39:14');

-- --------------------------------------------------------

--
-- Nadomestna struktura pogleda `ucenec_predmet`
-- (Oglejte si spodaj za resnični pogled)
--
CREATE TABLE `ucenec_predmet` (
`ime` varchar(20)
,`idPredmeta` int(11)
,`priimek` varchar(20)
,`token` varchar(300)
,`imePredmeta` varchar(30)
,`letnik` int(1)
,`okrajsava` varchar(6)
,`imeUcitelja` varchar(30)
,`priimekUcitelja` varchar(30)
,`emailUcitelja` varchar(30)
,`datumPrijaveUcitelja` datetime
,`datumPridruzitve` timestamp
,`datumPridruzitveUcitelja` timestamp
);

-- --------------------------------------------------------

--
-- Struktura tabele `ucitelji`
--

CREATE TABLE `ucitelji` (
  `idUcitelja` int(11) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `priimek` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `geslo` varchar(100) NOT NULL,
  `token` varchar(300) NOT NULL,
  `datumPrijave` datetime NOT NULL,
  `datumPridruzitve` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `ucitelji`
--

INSERT INTO `ucitelji` (`idUcitelja`, `ime`, `priimek`, `email`, `geslo`, `token`, `datumPrijave`, `datumPridruzitve`) VALUES
(1, 'Steven', 'Freeman', 'sf@gmail.com', '', '', '2022-09-29 22:23:24', '2022-09-29 20:23:48'),
(2, 'Danielle', 'Brown', 'db@gmail.com', '', '', '2022-09-29 22:23:24', '2022-09-29 20:23:48');

-- --------------------------------------------------------

--
-- Struktura tabele `uciteljpredmet`
--

CREATE TABLE `uciteljpredmet` (
  `idUciteljPredmet` int(11) NOT NULL,
  `idUcitelja` int(11) NOT NULL,
  `idPredmeta` int(11) NOT NULL,
  `datum` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `uciteljpredmet`
--

INSERT INTO `uciteljpredmet` (`idUciteljPredmet`, `idUcitelja`, `idPredmeta`, `datum`) VALUES
(1, 1, 1, '2022-09-27 14:40:01'),
(2, 2, 2, '2022-09-27 14:47:45'),
(3, 1, 3, '2022-09-29 20:24:01'),
(5, 1, 4, '2022-09-27 14:48:00'),
(6, 1, 7, '2022-09-29 20:24:24'),
(7, 2, 8, '2022-09-29 20:24:24'),
(8, 1, 9, '2022-09-29 20:24:31');

-- --------------------------------------------------------

--
-- Struktura pogleda `naloga_predmet`
--
DROP TABLE IF EXISTS `naloga_predmet`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `naloga_predmet`  AS SELECT `naloge`.`id` AS `id`, `naloge`.`ime` AS `ime`, `naloge`.`navodila` AS `navodila`, `naloge`.`datumObjave` AS `datumObjave`, `naloge`.`datumPoteka` AS `datumPoteka`, `naloge`.`idPredmeta` AS `idPredmeta`, `ucenci`.`token` AS `token` FROM (((`naloge` join `predmeti` on(`naloge`.`idPredmeta` = `predmeti`.`idPredmeta`)) join `ucenecpredmet` on(`ucenecpredmet`.`idPredmet` = `predmeti`.`idPredmeta`)) join `ucenci` on(`ucenecpredmet`.`idUcenec` = `ucenci`.`id`))  ;

-- --------------------------------------------------------

--
-- Struktura pogleda `ucenec_predmet`
--
DROP TABLE IF EXISTS `ucenec_predmet`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ucenec_predmet`  AS SELECT `ucenci`.`ime` AS `ime`, `predmeti`.`idPredmeta` AS `idPredmeta`, `ucenci`.`priimek` AS `priimek`, `ucenci`.`token` AS `token`, `predmeti`.`imePredmeta` AS `imePredmeta`, `predmeti`.`letnik` AS `letnik`, `predmeti`.`okrajsava` AS `okrajsava`, `ucitelji`.`ime` AS `imeUcitelja`, `ucitelji`.`priimek` AS `priimekUcitelja`, `ucitelji`.`email` AS `emailUcitelja`, `ucitelji`.`datumPrijave` AS `datumPrijaveUcitelja`, `ucenecpredmet`.`datumPridruzitve` AS `datumPridruzitve`, `uciteljpredmet`.`datum` AS `datumPridruzitveUcitelja` FROM ((((`ucenci` join `ucenecpredmet`) join `ucitelji`) join `uciteljpredmet`) join `predmeti`) WHERE `ucenci`.`id` = `ucenecpredmet`.`idUcenec` AND `ucenecpredmet`.`idPredmet` = `predmeti`.`idPredmeta` AND `uciteljpredmet`.`idPredmeta` = `predmeti`.`idPredmeta` AND `uciteljpredmet`.`idUcitelja` = `ucitelji`.`idUcitelja``idUcitelja`  ;

--
-- Indeksi zavrženih tabel
--

--
-- Indeksi tabele `naloge`
--
ALTER TABLE `naloge`
  ADD PRIMARY KEY (`id`);

--
-- Indeksi tabele `oddanenaloge`
--
ALTER TABLE `oddanenaloge`
  ADD PRIMARY KEY (`id`);

--
-- Indeksi tabele `predmeti`
--
ALTER TABLE `predmeti`
  ADD PRIMARY KEY (`idPredmeta`);

--
-- Indeksi tabele `ucenci`
--
ALTER TABLE `ucenci`
  ADD PRIMARY KEY (`id`);

--
-- Indeksi tabele `ucenecpredmet`
--
ALTER TABLE `ucenecpredmet`
  ADD PRIMARY KEY (`idUcenecPredmet`);

--
-- Indeksi tabele `ucitelji`
--
ALTER TABLE `ucitelji`
  ADD PRIMARY KEY (`idUcitelja`);

--
-- Indeksi tabele `uciteljpredmet`
--
ALTER TABLE `uciteljpredmet`
  ADD PRIMARY KEY (`idUciteljPredmet`);

--
-- AUTO_INCREMENT zavrženih tabel
--

--
-- AUTO_INCREMENT tabele `naloge`
--
ALTER TABLE `naloge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT tabele `oddanenaloge`
--
ALTER TABLE `oddanenaloge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT tabele `predmeti`
--
ALTER TABLE `predmeti`
  MODIFY `idPredmeta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT tabele `ucenci`
--
ALTER TABLE `ucenci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT tabele `ucenecpredmet`
--
ALTER TABLE `ucenecpredmet`
  MODIFY `idUcenecPredmet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT tabele `ucitelji`
--
ALTER TABLE `ucitelji`
  MODIFY `idUcitelja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT tabele `uciteljpredmet`
--
ALTER TABLE `uciteljpredmet`
  MODIFY `idUciteljPredmet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
