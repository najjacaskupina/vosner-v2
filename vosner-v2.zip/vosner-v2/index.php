<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Domača stran</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/index-login.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/index.js"></script>

</head>
<body>
    <main>
    <header></header>
    <div class="id1">
        <div class="id1-box">
            <h1>E učilnica</h1>
            <p>To je spletna učilnica za učence Šolskega centra Celje. Pridružite se spodaj.</p>
        </div>
    </div>
    <section class="login-section">
        <h2>Prijava</h2>
        <form class="login" method="post" action="server/login.php">
            <input name="email" id="prijava-mail" type="email" placeholder="E-mail" onkeydown="validatePrijava()">
            <input name="password" id="prijava-geslo" type="password" placeholder="Geslo" onkeydown="validatePrijava()">
            <input type="hidden" name="key" value="log">
            <input type="submit" id="loginBtn" class="submitBtn" value="Prijava" enabled>
        </form>    
    </section>
    <div class="id2"></div>
    <section class="login-section">
        <h2>Registracija</h2>
          <form class="login" method="post" action="server/login.php">
            <input name="email" id="registracija-mail" type="email" placeholder="E-mail" onkeydown="validateReg()">
            <input name="password" id="registracija-geslo" type="password" placeholder="Geslo" onkeydown="validateReg()">
            <input type="hidden" name="key" value="reg">
            <input type="submit" id="regBtn" class="submitBtn" value="Registracija" enabled>
          </form>    
    </section>
    <div class="id3"></div>
    <section class="login-section">
        <h2>Učitelji</h2>
        <form class="login" method="post" action="server/login.php">
            <input name="email" id="loginU-mail" type="email" placeholder="E-mail" onkeydown="validatePrijavaU()">
            <input name="password" id="loginU-geslo" type="password" placeholder="Geslo" onkeydown="validatePrijavaU()">
            <input type="hidden" name="key" value="logU">
            <input type="submit" id="loginUBtn" class="submitBtn" value="Prijava Učitelja" enabled>
        </form>      
    </section>
    <div class="id4"></div>
    <footer>
        <h2>O šoli</h2>
        <p>Šolski center Celje je slovenski javni vzgojno-izobraževalni zavod, s sedežem na Poti na Lavo 22 v Celju. Združuje gimnazijo, štiri srednje strokovne šole, višjo strokovno šolo in medpodjetniški izobraževalni center. Je eden največjih šolskih centrov v Sloveniji.</p>
    </footer>
</main>
</body>
</html>