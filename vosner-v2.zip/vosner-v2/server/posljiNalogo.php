<?php
include 'conn.php';
include 'session.php';

$idn= $_POST['idNaloge'];
$filename = $_FILES['file']['name'];
$location = "C:/xampp/htdocs/4Letnik/naloge/".$id."/".$idn."-".$ime."-".$priimek."-".$filename;
$dbLoc = $id."/".$idn."-".$ime."-".$priimek."-".$filename;
echo $filename;
print_r($_FILES);
if (move_uploaded_file($_FILES['file']['tmp_name'], $location)) {
    $sql = "insert into oddanenaloge (idNaloge, idUcenca, pot) values ('$idn', '$id', '$dbLoc')";
    $result = mysqli_query($conn, $sql);
    header("Location: ../domov.php");
}else{
    echo "Error";
}
?>