<?php
include 'conn.php';
include 'session.php';
if(isset($_POST['key'])){
    if($_POST['key']=="updPsw"){
        $password = $_POST['password'];
        if(strlen($password) < 5){
            exit("Password too short");
        }
        $password = mysqli_real_escape_string($conn, $password);
        $password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE ucenci SET geslo = '$password' WHERE token = '$token';";
        mysqli_query($conn, $sql);
        exit("Success on updating password");
    }if($_POST['key']=="updData"){
        $email = $_POST['email'];
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            exit("Not email");
        }
        $sql = "select * from ucenci where email = '$email' and token != '$token'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result)>=1){
            exit("User exists");
        }else{
        $password = $_POST['password'];
        if (strlen($password) > 5) {
        $password = mysqli_real_escape_string($conn, $password);
        $password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE ucenci SET geslo = '$password' WHERE token = '$token';";
        mysqli_query($conn, $sql);
        } 
            $ime = $_POST['ime'];
            $priimek = $_POST['priimek'];
            $ime = ucfirst($ime);
            $priimek = ucfirst($priimek);
            $sql = "UPDATE ucenci SET ime = '$ime', priimek = '$priimek', email = '$email' WHERE token = '$token';";
            mysqli_query($conn, $sql);
            header("Location: ../domov.php");
            
        }
    }
}exit("not post");
?>