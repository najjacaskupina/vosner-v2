<?php
include 'conn.php';

$cypherMethod = 'AES-256-CBC';
$key = "myApp27";
$iv = '1234567891011121';

if(isset($_POST['key'])){
    $email = $_POST['email'];
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        exit("Not email");
    }
    $email = mysqli_real_escape_string($conn, $email);
    $password = $_POST['password'];
    if(strlen($password) < 3){
        exit("Password too short");
    }
    $password = mysqli_real_escape_string($conn, $password);

    if($_POST['key']=="reg"){
        $sql = "select * from ucenci where email = '$email'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result)>=1){
            exit("User exists");
        }else{
            $password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "insert into ucenci (email, geslo) values ('$email', '$password')";
            mysqli_query($conn, $sql);
            $sql = "select * from ucenci where email = '$email'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_array($result);
            $id = $row['id'];
            $time = time();
            $tokenId = $id . $time;
            $token = openssl_encrypt($tokenId, $cypherMethod, $key, $options=0, $iv);
            $sql = "UPDATE ucenci SET token = '$token' WHERE email = '$email'";
            mysqli_query($conn, $sql);
            session_start();
            $_SESSION['token'] = $token;
            $dir = $id;
            if(is_dir($dir) === false )
            {
                mkdir($dir);
            }

            header('Location: ../domov.php');
        }
        exit("failed");
    }

    if($_POST['key']=="log"){
        $sql = "select * from ucenci where email = '$email'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        $id = $row['id'];
        $time = time();
        $tokenId = $id . $time;
        if($row != null){
            $dbpass = $row['geslo'];
            if(password_verify($password, $dbpass)){
            $token = openssl_encrypt($tokenId, $cypherMethod, $key, $options=0, $iv);
            $sql = "UPDATE ucenci SET token = '$token' WHERE id = '$id'";
            mysqli_query($conn, $sql);
            session_start();
            $_SESSION['token'] = $token;
            header("location: ../domov.php");
            echo "Token: ".$token;
            }else{echo "narobe geslo";}
        }else{echo "mail ne obstaja";}
        
    }
}
?>