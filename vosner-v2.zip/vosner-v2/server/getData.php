<?php
include 'conn.php';
if(isset($_POST['key'])){
    if (isset($_POST['token'])) {
        $token = $_POST['token'];
    }
    
    if($_POST['key']=="chkTKN"){
        $sql = "select * from ucenci where token = '$token'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        if($row == null){
            exit("Wrong token");
        }else{
            $row['geslo'] = "skrito";
            exit(json_encode($row));
            
        }
    }
    if($_POST['key']=="mojiPredmeti"){
        $sql = "select * from ucenec_predmet where token = '$token'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        if($row == null){
            exit("Wrong token");
        }else{
            exit(json_encode($result));
            
        }
    }
    if($_POST['key']=="naloga"){
        $id = $_POST['id'];
        $sql = "select * from naloge where id = '$id'";
        $result = mysqli_query($conn, $sql);
        
        if(mysqli_num_rows($result)<1){
            exit("Wrong");
        }else{
            $row = mysqli_fetch_array($result);
            exit(json_encode($row));
            
        }
    }

    if($_POST['key']=="oddanaNaloga"){
        $idNal = $_POST['idNal'];
        $id = $_POST['id'];
        $sql = "select * from oddanenaloge where idNaloge = '$idNal' and idUcenca = '$id'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result)<1){
            exit("Ni opravil");
        }else{
            exit("Opravil");
            
        }
    }else{
        exit("hi");
    }
}


    
?>