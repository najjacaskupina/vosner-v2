function chkTKN(){
    if (checkToken()==false) {
        window.location = "index.php";
    }else {
        $.ajax({
        url: 'server/getData.php',
        method: 'POST',
        dataType: 'json',
        data:{
            key: "chkTKN",
            token: sessionStorage.getItem('token')}, 
            success: function(response){
                if(response['ime'] == "" || response['priimek'] == ""){
                    window.location = 'uredi-profil.php';
                }
                fillData(response);
            }
        })
    }
}
function checkToken(){
    if(getCookie("token")==""){
        return false;
    }else{
        return true;
    }
}