function main(){
    chkTKN();
}
function fillData(a){
    console.log(a);
}