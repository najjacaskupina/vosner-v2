<!DOCTYPE html>
<html lang="en">
<head>
<?php
    include 'server/conn.php';
    include 'server/session.php';
    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Domov</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/domov.css">
    <link rel="stylesheet" href="css/sidebar.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
      function visit(num){
        window.location = "predmet.php?id="+num;
      }
    </script>
    
</head>
<body>

        <div class="container">
        <aside class="sidebar" data-sidebar>
          <div class="top-sidebar">
            <div class="eucilnica">E-učilnica</div>
          </div>
          <div class="middle-sidebar">
            <ul class="sidebar-list">
              <li class="sidebar-list-item active">
                <a href="#" class="sidebar-link">
                  <img class="sidebar-icon" src="images/profil.png" alt="ocene">
                  <div class="sidebar-text">Moj profil</div>
                </a>
              </li>
              <li class="sidebar-list-item">
                <a href="vsiPredmeti.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/predmeti.png" alt="ocene">
                  <div class="sidebar-text">Predmeti</div>
                </a>
              </li>
              <li class="sidebar-list-item">
                <a href="ocene.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/ocene.png" alt="ocene">
                  <div class="sidebar-text">Ocene</div>
                </a>
              </li>
              <li class="sidebar-list-item">
                <a href="vseNaloge.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/vaje.png" alt="ocene">
                  <div class="sidebar-text">Naloge</div>
                </a>
              </li>
              <li class="sidebar-list-item">
                <a href="server/odjava.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/logout.png" alt="ocene">
                  <div class="sidebar-text">Odjava</div>
                </a>
              </li>
            </ul>
          </div>
          <div class="bottom-sidebar">
            <ul class="sidebar-list">
                <li class="sidebar-list-item">
                    <a href="vaje.php" class="sidebar-link">
                      <img class="sidebar-icon" src="images/nastvitve.png" alt="ocene">
                      <div class="sidebar-text">Nastavitve</div>
                    </a>
                  </li>
                  <li class="sidebar-list-item">
                    <a href="vaje.php" class="sidebar-link">
                      <img class="sidebar-icon" src="images/bug.png" alt="ocene">
                      <div class="sidebar-text">Bugi</div>
                    </a>
                  </li>
            </ul>
          </div>
        </aside>
        <main>
            <div class="profile-container">
                <img class="profile-image" src="images/profil.png" alt="ocene">
                <div class="profile-data">
                  <?php
                  $sql = "select * from ucenci where token = '$token'";
                  $result = mysqli_query($conn, $sql);
                  $row = mysqli_fetch_array($result);
                  if ($row['ime'] == "" || $row['priimek'] == "" ) {
                    header("Location: uredi-profil.php");
                  }
                  echo"
                    <div>Ime: <span>".$row['ime']."</span></div>
                    <div>Priimek: <span>".$row['priimek']."</span> </div>
                    <div>E-mail: <span>".$row['email']."</span> </div>";    
                  ?>
                </div>
                <div class="profile-data">
                    <div></div>
                    <div>Povprečna ocena: <span id="povprecnaOcena"></span> </div>
                    <div></div>
                </div>
                <div class="profile-data-edit">
                    <button class="urediBtn aniBtn" onclick="location = 'uredi-profil.php'">Uredi</button>
                </div>
            </div>
            <h1 class="mojiPredmetiHeader">Moji predmeti</h1>
        <div class="predmeti-container">
            <div class="moji-predmeti">
              <?php
              $sql = "select * from ucenec_predmet where token = '$token'";
              $result = mysqli_query($conn, $sql);
              $row = mysqli_fetch_array($result);
              if($row == null){
                  echo "<a href='vsiPredmeti.php'>Nisi prijavljen v noben predmet";
              }else {
                $sql = "select * from ucenec_predmet where token = '$token'";
                $result = mysqli_query($conn, $sql);
                while($row = mysqli_fetch_array($result)){
                  $okr = strtolower($row['okrajsava']);
                  echo '<div onclick="visit('.$row['idPredmeta'].')"><img src="images/'.$okr.'.jpg"> <span>'.$row['imePredmeta']." ".$row['letnik'].'</span></div>';
                }
              }
              
              ?>
            </div>
        </div>
        </main>
      </div>
</body>
</html>